from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import random
import os

app = Flask(__name__)
app.secret_key = "super_secret_key_iqzwo_platform"

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email_or_phone TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            claimed_username TEXT UNIQUE,
            is_owner INTEGER DEFAULT 0
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    identifier = request.form.get('identifier', '').strip()
    password = request.form.get('password', '').strip()
    
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, password, is_owner FROM users WHERE email_or_phone = ?", (identifier,))
    user = cursor.fetchone()
    conn.close()
    
    if user and check_password_hash(user[1], password):
        # توليد رمز تحقق OTP مكون من 6 أرقام
        otp_code = str(random.randint(100000, 999999))
        session['pending_user_id'] = user[0]
        session['pending_identifier'] = identifier
        session['otp_code'] = otp_code
        
        # تسجيل محاولة الدخول في السجلات
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO logs (action, details) VALUES (?, ?)", 
                       ("طلب دخول (OTP)", f"تم إرسال رمز التحقق {otp_code} إلى: {identifier}"))
        conn.commit()
        conn.close()
        
        return redirect(url_for('verify'))
    
    flash("خطأ في بيانات الدخول (البريد/الجوال أو كلمة المرور)", "error")
    return redirect(url_for('index'))

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if 'pending_user_id' not in session:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        user_otp = request.form.get('otp', '').strip()
        if user_otp == session.get('otp_code'):
            session['user_id'] = session.get('pending_user_id')
            
            # تنظيف بيانات الـ OTP المؤقتة
            user_id = session.pop('pending_user_id', None)
            identifier = session.pop('pending_identifier', None)
            session.pop('otp_code', None)
            
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO logs (action, details) VALUES (?, ?)", 
                           ("تسجيل دخول ناجح", f"تم تأكيد OTP وتسجيل الدخول بنجاح لـ: {identifier}"))
            conn.commit()
            conn.close()
            
            return redirect(url_for('dashboard'))
        else:
            flash("رمز التحقق غير صحيح، حاول مجدداً!", "error")
            
    return render_template('verify.html', identifier=session.get('pending_identifier'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT username, email_or_phone, claimed_username, is_owner FROM users WHERE id = ?", (session['user_id'],))
    user = cursor.fetchone()
    
    logs = []
    if user and user[3] == 1:
        cursor.execute("SELECT action, details, timestamp FROM logs ORDER BY id DESC LIMIT 25")
        logs = cursor.fetchall()
        
    if request.method == 'POST':
        new_username = request.form.get('claimed_username', '').strip().lower()
        
        if len(new_username) < 2:
            flash("يجب ألا يقل اليوزر عن حرفين!", "error")
        else:
            try:
                cursor.execute("UPDATE users SET claimed_username = ? WHERE id = ?", (new_username, session['user_id']))
                cursor.execute("INSERT INTO logs (action, details) VALUES (?, ?)", 
                               ("حجز يوزر", f"المستخدم {user[0]} قام بحجز اليوزر: {new_username}"))
                conn.commit()
                flash("تم حجز اليوزر بنجاح!", "success")
                return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError:
                flash("هذا اليوزر مأخوذ مسبقاً، اختر غيره.", "error")
                
    conn.close()
    return render_template('dashboard.html', user=user, logs=logs)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
